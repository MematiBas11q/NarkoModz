package com.example.modmenu;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class ModMenuGuiScreen extends Screen {

    public ModMenuGuiScreen() {
        super(Text.literal("NarkoModz Client Menu"));
    }

    @Override
    protected void init() {
        super.init();
        // Butonlar ve arayüz elemanları buraya eklenecek
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Arka planı karart
        this.renderBackground(context, mouseX, mouseY, delta);
        
        // Menü Başlığı
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 30, 0xFF0050);

        // Özellik Durumlarını Ekrana Yazdır
        context.drawTextWithShadow(this.textRenderer, "Box ESP: " + (NarkoModzClient.boxEspEnabled ? "§aON" : "§cOFF"), 50, 80, -1);
        context.drawTextWithShadow(this.textRenderer, "Line ESP: " + (NarkoModzClient.lineEspEnabled ? "§aON" : "§cOFF"), 50, 110, -1);
        context.drawTextWithShadow(this.textRenderer, "Health ESP: " + (NarkoModzClient.healthEspEnabled ? "§aON" : "§cOFF"), 50, 140, -1);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false; // Oyun arka planda durmasın
    }
}
