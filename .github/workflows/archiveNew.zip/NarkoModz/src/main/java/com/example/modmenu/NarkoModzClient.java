package com.example.modmenu;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.awt.Color;

public class NarkoModzClient implements ClientModInitializer {

    private static KeyBinding menuKey;
    
    // ESP Özellikleri (Varsayılan olarak açık)
    public static boolean boxEspEnabled = true;
    public static boolean healthEspEnabled = true;
    public static boolean lineEspEnabled = true;
    
    // Varsayılan Renk: Kan Kırmızısı / Neon
    public static Color espColor = new Color(255, 0, 50);

    @Override
    public void onInitializeClient() {
        // Sağ Shift (RShift) ile menüyü açma tuşu
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.narkomodz.menu",
                InputUtil.Type.KEY_SYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.narkomodz.main"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                if (client.player != null) {
                    // Mod Menü GUI ekranını açar
                    client.setScreen(new ModMenuGuiScreen());
                }
            }
        });

        // ESP Çizim Döngüsü
        WorldRenderEvents.LAST.register(context -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null || client.world == null) return;

            for (PlayerEntity player : client.world.getPlayers()) {
                if (player == client.player) continue;

                Vec3d pos = player.getPos();

                if (boxEspEnabled) {
                    renderBoxEsp(context, pos, espColor);
                }

                if (lineEspEnabled) {
                    renderLineEsp(context, pos, espColor);
                }

                if (healthEspEnabled) {
                    float health = player.getHealth();
                    // Can barı mantığı burada işlenir
                }
            }
        });
    }

    private void renderBoxEsp(WorldRenderEvents.Context context, Vec3d pos, Color color) {
        // 3D Box ESP Çizim Kodları
    }

    private void renderLineEsp(WorldRenderEvents.Context context, Vec3d pos, Color color) {
        // Tracer Çizgi Çizim Kodları
    }
}
